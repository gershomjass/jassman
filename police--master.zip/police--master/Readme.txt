#the login to the database are SHA1 encrypted. 
#you can encrypt any string and update it in the database column Password
#enjoy
#the application is free and thus you are free to redistribute, edit or anything you want to do with it.
#follow me @github, @the_p1rate in twitter and Netsploit in Youtube
