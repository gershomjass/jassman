<div class="row sidebar">
<img src="../Assets/imgs/title.png"width="220px"height="150px"/>
<ul class="list-group">
    <li class="list-group-item"><a href="assualt.php">Report Assualt</a></li>
  <li class="list-group-item"><a href="add_convict.php">New Charges</a></li>
  <li class="list-group-item"><a href="cells_details.php">Cells</a></li>
  <li class="list-group-item"><a href="statements.php">Statements</a></li>
  <li class="list-group-item"><a href="cases.php">Case OutComes</a></li>
  <li class="list-group-item"><a href="re.php">Statement_remarks</a></li>
  <li class="list-group-item"><a href="all.php">All Assualt Claims</a></li>
</ul>
</div>
