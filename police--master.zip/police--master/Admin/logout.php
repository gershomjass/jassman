<?php
session_start();
session_destroy();
if(true){
  header("Location: ../");
}
 ?>
